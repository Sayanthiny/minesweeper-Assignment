package minesweeperproblem.minesweeperproblem;

public class MineSweeperGame {
    private final GameBoard gameBoard;
    private boolean gameOver;

    public MineSweeperGame(int size, int numMines) {
        this.gameBoard = new GameBoard(size, numMines);
        this.gameOver = false;
    }

    public void selectSquare(String input) {
//        input string should be e.g., "A1", "B3" mean more than 2 letter
        if (input.length() < 2) {
            System.out.println("Invalid input. Try again.");
            return;
        }

        int row = input.charAt(0) - 'A';
        int col = Integer.parseInt(input.substring(1)) - 1;

        if (row < 0 || row >= gameBoard.getSize() || col < 0 || col >= gameBoard.getSize()) {
            System.out.println("Invalid square. Try again.");
            return;
        }

        if (gameBoard.isRevealed(row, col)) {
            System.out.println("Square already revealed. Try again.");
            return;
        }

        if (gameBoard.isMine(row, col)) {
            System.out.println("Oh no, you detonated a mine! Game over.");
            gameOver = true;
        } else {
            gameBoard.revealSquare(row, col);
            if (checkWin()) {
                gameBoard.displayGrid();
                System.out.println("Congratulations, you have won the game!");
                gameOver = true;
            }
        }
    }

    private boolean checkWin() {
        for (int i = 0; i < gameBoard.getSize(); i++) {
            for (int j = 0; j < gameBoard.getSize(); j++) {
                if (!gameBoard.isMine(i, j) && !gameBoard.isRevealed(i, j)) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void displayGrid() {
        gameBoard.displayGrid();
    }
}

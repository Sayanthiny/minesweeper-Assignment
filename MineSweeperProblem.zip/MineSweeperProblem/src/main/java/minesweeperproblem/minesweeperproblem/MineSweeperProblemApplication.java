package minesweeperproblem.minesweeperproblem;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class MineSweeperProblemApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  // Create Scanner object

        System.out.println("Welcome to Minesweeper!");
        System.out.print("Enter the size of the grid (e.g., 4 for a 4x4 grid): ");
        int size = scanner.nextInt();// Reads an integer from user input
        System.out.print("Enter the number of mines to place on the grid (maximum is 35% of the total squares): ");
        int numMines = scanner.nextInt();

        if (numMines > 0.35 * size * size) {
            System.out.println("Number of mines exceeds the allowed limit.");
            return;
        }

        MineSweeperGame game = new MineSweeperGame(size, numMines);

        while (!game.isGameOver()) {
            game.displayGrid();
            System.out.print("Select a square to reveal (e.g., A1): ");
            String input = scanner.next();
            game.selectSquare(input);
        }

        scanner.close();
    }
}

package minesweeperproblem.minesweeperproblem.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GameConfig {

    @Value("${game.max-mine-percentage:0.35}")
    private double maxMinePercentage;

    public double getMaxMinePercentage() {
        return maxMinePercentage;
    }

    public void setMaxMinePercentage(double maxMinePercentage) {
        this.maxMinePercentage = maxMinePercentage;
    }
}

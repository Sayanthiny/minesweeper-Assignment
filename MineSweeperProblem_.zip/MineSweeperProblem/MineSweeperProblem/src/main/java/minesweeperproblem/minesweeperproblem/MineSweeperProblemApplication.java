package minesweeperproblem.minesweeperproblem;

import minesweeperproblem.minesweeperproblem.config.GameConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MineSweeperProblemApplication {

    @Autowired
    private GameConfig gameConfig;

    public static void main(String[] args) {
        SpringApplication.run(MineSweeperProblemApplication.class, args);
    }

    @Bean
    public CommandLineRunner runGame(ApplicationContext ctx) {
        return args -> {
            GameRunner gameRunner = ctx.getBean(GameRunner.class);
            System.out.println("Max Mine Percentage: " + gameConfig.getMaxMinePercentage());
            gameRunner.startGame();
        };
    }
}

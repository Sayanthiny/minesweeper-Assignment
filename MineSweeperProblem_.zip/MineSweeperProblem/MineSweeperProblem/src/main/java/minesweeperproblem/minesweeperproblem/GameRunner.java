package minesweeperproblem.minesweeperproblem;

import minesweeperproblem.minesweeperproblem.config.GameConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Scanner;

@Component
public class GameRunner {
    private static final Logger logger = LoggerFactory.getLogger(GameRunner.class);
    private final Scanner scanner = new Scanner(System.in);
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private GameConfig gameConfig;

    private String getMessage(String key) {
        return messageSource.getMessage(key, null, Locale.getDefault());
    }


    public void startGame() {
        logger.info("Starting Minesweeper game...");

        System.out.println(getMessage("game.welcome"));

        int size = getValidInteger("game.enterSize");

        // Use maxMinePercentage from GameConfig
        int maxMines = (int) (gameConfig.getMaxMinePercentage() * size * size);
        int numMines;

        for (;;) {
            numMines = getValidInteger("game.enterMines");
            if (numMines <= maxMines) {
                break;
            }
            System.out.println("Please enter a valid range (max: " + maxMines + ").");
        }

        MineSweeperGame game = new MineSweeperGame(size, numMines);

        while (!game.isGameOver()) {
            game.displayGrid();
            System.out.print(getMessage("game.selectSquare"));

            String input = scanner.next();
            if (!isValidGridInput(input, size)) {
                System.out.println(getMessage("game.invalidPosition"));
                continue;
            }

            game.selectSquare(input);
        }

        logger.info(getMessage("game.gameOver"));
    }

    private int getValidInteger(String messageKey) {
        for (;;) {
            System.out.print(getMessage(messageKey));
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            }
            System.out.println(getMessage("game.invalidNumber"));
            scanner.next();
        }
    }

    private boolean isValidGridInput(String input, int gridSize) {
        if (input.length() != 2) {
            return false;
        }

        char row = input.charAt(0);
        char col = input.charAt(1);
        if (row < 'A' || row > 'A' + gridSize - 1) {
            return false;
        }

        if (col < '1' || col > '0' + gridSize) {
            return false;
        }

        return true;
    }


}

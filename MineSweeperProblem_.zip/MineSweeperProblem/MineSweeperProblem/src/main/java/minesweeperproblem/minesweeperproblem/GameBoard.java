package minesweeperproblem.minesweeperproblem;

import java.util.Arrays;
import java.util.Random;

public class GameBoard {
    private final int size;
    private final int numMines;
    private final char[][] grid;
    private final boolean[][] mines;
    private final boolean[][] revealed;

    public GameBoard(int size, int numMines) {
        this.size = size;
        this.numMines = numMines;
        this.grid = new char[size][size];
        this.mines = new boolean[size][size];
        this.revealed = new boolean[size][size];
        initializeGrid();
        placeMines();
    }
    private void initializeGrid() {
        for (int i = 0; i < size; i++) {
             Arrays.fill(grid[i], '_');
        }
    }

     private void placeMines() {
        Random rand = new Random();
        int minesPlaced = 0;

        while (minesPlaced < numMines) {
            int row = rand.nextInt(size);
            int col = rand.nextInt(size);
                if (!mines[row][col]) {
                    mines[row][col] = true;
                    minesPlaced++;
                }
        }
    }

    public int getSize() {
        return size;
    }

    public boolean isMine(int row, int col) {
        return mines[row][col];
    }

    public boolean isRevealed(int row, int col) {
        return revealed[row][col];
    }

    public void revealSquare(int row, int col) {
        if (row < 0 || row >= size || col < 0 || col >= size || revealed[row][col]) {
            return;
        }

        revealed[row][col] = true;
        int adjacentMines = countAdjacentMines(row, col);

        grid[row][col] = (char) (adjacentMines + '0');
        if (adjacentMines == 0) {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    revealSquare(row + i, col + j);
                }
            }
        }
    }


    private int countAdjacentMines(int row, int col) {
        int count = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int newRow = row + i;
                int newCol = col + j;
                if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size && mines[newRow][newCol]) {
                    count++;
                }
            }
        }
        return count;
    }

    public void displayGrid() {

        System.out.print("  ");
        for (int i = 1; i <= size; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
        for (int i = 0; i < size; i++) {
            System.out.print((char) ('A' + i) + " ");
            for (int j = 0; j < size; j++) {
                if (revealed[i][j]) {
                    System.out.print(grid[i][j] + " ");
                } else {
                    System.out.print("_ ");
                }
            }
            System.out.println();
        }
    }
}

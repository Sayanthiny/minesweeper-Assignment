package minesweeperproblem.minesweeperproblem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class MineSweeperGameTest {
    private MineSweeperGame game;

    @BeforeEach
    void setUp() {
        game = new MineSweeperGame(5, 5);
    }

    @Test
    void testInvalidInput() {
        game.selectSquare("Z1");
        game.selectSquare("A");
        game.selectSquare("A100");
    }

    @Test
    void testGameNotOverInitially() {
        assertFalse(game.isGameOver(), "Game should not be over at the start.");
    }
}

package minesweeperproblem.minesweeperproblem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GameBoardTest {
    private GameBoard gameBoard;

    @BeforeEach
    void setUp() {
        gameBoard = new GameBoard(5, 5);
    }

    @Test
    void testMinePlacement() {
        int mineCount = 0;
        for (int i = 0; i < gameBoard.getSize(); i++) {
            for (int j = 0; j < gameBoard.getSize(); j++) {
                if (gameBoard.isMine(i, j)) {
                    mineCount++;
                }
            }
        }
        assertEquals(5, mineCount, "Incorrect number of mines placed.");
    }

    @Test
    void testRevealNonMineSquare() {
        for (int i = 0; i < gameBoard.getSize(); i++) {
            for (int j = 0; j < gameBoard.getSize(); j++) {
                if (!gameBoard.isMine(i, j)) {
                    gameBoard.revealSquare(i, j);
                    assertTrue(gameBoard.isRevealed(i, j), "Square should be revealed.");
                    return;
                }
            }
        }
    }

    @Test
    void testRevealMineEndsGame() {
        boolean mineRevealed = false;
        for (int i = 0; i < gameBoard.getSize(); i++) {
            for (int j = 0; j < gameBoard.getSize(); j++) {
                if (gameBoard.isMine(i, j)) {
                    gameBoard.revealSquare(i, j);
                    mineRevealed = true;
                    break;
                }
            }
            if (mineRevealed) break;
        }
        assertTrue(mineRevealed, "A mine should have been revealed.");
    }
}

